# CloserAI API — NestJS + Supabase

Backend inicial do CloserAI, preparado para GitHub e Vercel.

## O que já existe

- NestJS + TypeScript
- autenticação por Supabase JWT
- CORS
- validação de DTOs
- RLS no Supabase
- empresas
- clientes
- conversas
- vendas
- configuração do agente IA
- base de conhecimento
- endpoints iniciais de webhook
- estrutura pronta para crescer

## 1. Instalar

```bash
npm install
```

## 2. Configurar Supabase

Copie `.env.example` para `.env` e preencha:

```env
SUPABASE_URL=https://SEU-PROJETO.supabase.co
SUPABASE_ANON_KEY=SUA_CHAVE_ANON
PORT=3000
NODE_ENV=development
```

No SQL Editor do Supabase, execute:

`supabase/schema.sql`

IMPORTANTE: use somente a chave `anon`/publishable no backend desta arquitetura. Nunca coloque a `service_role` no GitHub.

## 3. Rodar

```bash
npm run start:dev
```

API local:

`http://localhost:3000/api`

## Autenticação

O frontend deve fazer login/cadastro com Supabase Auth e enviar o access token para a API:

```http
Authorization: Bearer SEU_ACCESS_TOKEN
```

## Endpoints principais

```text
POST /api/empresas
GET  /api/empresas

POST /api/clientes
GET  /api/clientes?empresa_id=UUID

POST /api/conversas
GET  /api/conversas?empresa_id=UUID

POST /api/vendas
GET  /api/vendas?empresa_id=UUID

POST /api/agentes
GET  /api/agentes?empresa_id=UUID

POST /api/conhecimento
GET  /api/conhecimento?empresa_id=UUID

GET  /api/webhooks/whatsapp
POST /api/webhooks/whatsapp
```

## GitHub

```bash
git init
git add .
git commit -m "Initial CloserAI NestJS API"
git branch -M main
git remote add origin SEU_REPOSITORIO_GITHUB
git push -u origin main
```

## Vercel

Importe o repositório GitHub na Vercel. A Vercel reconhece uma aplicação NestJS usando `src/main.ts`.

Adicione no projeto da Vercel:

- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `NODE_ENV=production`

Não publique `.env`.

## Próximas partes do CloserAI

1. Frontend/dashboard
2. integração real com o provedor oficial do WhatsApp
3. motor de IA
4. processamento de mensagens
5. follow-ups
6. métricas
7. pagamentos/planos
8. painel administrativo
