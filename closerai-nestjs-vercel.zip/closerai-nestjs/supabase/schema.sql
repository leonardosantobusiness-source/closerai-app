create extension if not exists pgcrypto;

create table if not exists public.empresas (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  nome text not null,
  descricao text,
  segmento text,
  whatsapp text,
  telegram text,
  site text,
  created_at timestamptz not null default now()
);

create table if not exists public.clientes (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references public.empresas(id) on delete cascade,
  nome text not null,
  telefone text,
  email text,
  origem text,
  status text default 'lead',
  created_at timestamptz not null default now()
);

create table if not exists public.conversas (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references public.empresas(id) on delete cascade,
  cliente_id uuid references public.clientes(id) on delete set null,
  canal text not null,
  status text default 'aberta',
  ultima_mensagem text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.vendas (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references public.empresas(id) on delete cascade,
  cliente_id uuid references public.clientes(id) on delete set null,
  produto text not null,
  valor numeric(12,2) not null default 0,
  status text default 'concluida',
  origem text,
  created_at timestamptz not null default now()
);

create table if not exists public.agentes_ia (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid unique not null references public.empresas(id) on delete cascade,
  nome text not null,
  personalidade text,
  objetivo text,
  instrucoes text,
  tom text,
  ativo boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.conhecimento (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references public.empresas(id) on delete cascade,
  titulo text not null,
  conteudo text not null,
  tipo text default 'geral',
  created_at timestamptz not null default now()
);

alter table public.empresas enable row level security;
alter table public.clientes enable row level security;
alter table public.conversas enable row level security;
alter table public.vendas enable row level security;
alter table public.agentes_ia enable row level security;
alter table public.conhecimento enable row level security;

create or replace function public.user_owns_empresa(eid uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.empresas
    where id = eid and owner_id = auth.uid()
  );
$$;

drop policy if exists empresas_owner_all on public.empresas;
create policy empresas_owner_all on public.empresas
for all using (owner_id = auth.uid())
with check (owner_id = auth.uid());

drop policy if exists clientes_empresa_owner on public.clientes;
create policy clientes_empresa_owner on public.clientes
for all using (public.user_owns_empresa(empresa_id))
with check (public.user_owns_empresa(empresa_id));

drop policy if exists conversas_empresa_owner on public.conversas;
create policy conversas_empresa_owner on public.conversas
for all using (public.user_owns_empresa(empresa_id))
with check (public.user_owns_empresa(empresa_id));

drop policy if exists vendas_empresa_owner on public.vendas;
create policy vendas_empresa_owner on public.vendas
for all using (public.user_owns_empresa(empresa_id))
with check (public.user_owns_empresa(empresa_id));

drop policy if exists agentes_empresa_owner on public.agentes_ia;
create policy agentes_empresa_owner on public.agentes_ia
for all using (public.user_owns_empresa(empresa_id))
with check (public.user_owns_empresa(empresa_id));

drop policy if exists conhecimento_empresa_owner on public.conhecimento;
create policy conhecimento_empresa_owner on public.conhecimento
for all using (public.user_owns_empresa(empresa_id))
with check (public.user_owns_empresa(empresa_id));
