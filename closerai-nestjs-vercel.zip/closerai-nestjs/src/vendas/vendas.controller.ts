import { Body, Controller, Get, Post, Query, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { VendasService } from './vendas.service';
import { CreateVendaDto } from './vendas.dto';

@Controller('vendas')
@UseGuards(AuthGuard)
export class VendasController {
  constructor(private readonly service: VendasService) {}

  @Post()
  create(@Req() req: any, @Body() dto: CreateVendaDto) {
    return this.service.create(req.accessToken, dto);
  }

  @Get()
  list(@Req() req: any, @Query('empresa_id') empresaId: string) {
    return this.service.list(req.accessToken, empresaId);
  }
}
