import { IsNumber, IsOptional, IsString, IsUUID, Min } from 'class-validator';

export class CreateVendaDto {
  @IsUUID()
  empresa_id!: string;

  @IsOptional()
  @IsUUID()
  cliente_id?: string;

  @IsString()
  produto!: string;

  @IsNumber()
  @Min(0)
  valor!: number;

  @IsOptional()
  @IsString()
  status?: string;

  @IsOptional()
  @IsString()
  origem?: string;
}
