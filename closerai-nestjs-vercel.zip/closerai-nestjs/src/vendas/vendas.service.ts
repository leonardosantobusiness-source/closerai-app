import { BadRequestException, Injectable } from '@nestjs/common';
import { SupabaseService } from '../common/supabase.service';
import { CreateVendaDto } from './vendas.dto';

@Injectable()
export class VendasService {
  constructor(private readonly supabase: SupabaseService) {}

  async create(token: string, dto: CreateVendaDto) {
    const { data, error } = await this.supabase.client(token)
      .from('vendas')
      .insert(dto)
      .select()
      .single();

    if (error) throw new BadRequestException(error.message);
    return data;
  }

  async list(token: string, empresaId: string) {
    const { data, error } = await this.supabase.client(token)
      .from('vendas')
      .select('*')
      .eq('empresa_id', empresaId)
      .order('created_at', { ascending: false });

    if (error) throw new BadRequestException(error.message);
    return data;
  }
}
