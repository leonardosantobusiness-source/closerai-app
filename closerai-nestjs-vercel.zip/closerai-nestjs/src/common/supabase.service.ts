import { Injectable, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

@Injectable()
export class SupabaseService {
  private readonly url: string;
  private readonly anonKey: string;

  constructor(private readonly config: ConfigService) {
    this.url = this.config.getOrThrow<string>('SUPABASE_URL');
    this.anonKey = this.config.getOrThrow<string>('SUPABASE_ANON_KEY');
  }

  public client(accessToken?: string): SupabaseClient {
    return createClient(this.url, this.anonKey, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: accessToken
        ? { headers: { Authorization: `Bearer ${accessToken}` } }
        : undefined,
    });
  }

  public async requireUser(accessToken?: string) {
    if (!accessToken) throw new UnauthorizedException('Bearer token ausente.');

    const { data, error } = await this.client(accessToken).auth.getUser(accessToken);
    if (error || !data.user) {
      throw new UnauthorizedException('Token inválido ou expirado.');
    }

    return data.user;
  }
}
