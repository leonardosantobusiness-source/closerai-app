import { BadRequestException, Injectable } from '@nestjs/common';
import { SupabaseService } from '../common/supabase.service';
import { CreateEmpresaDto } from './empresas.dto';

@Injectable()
export class EmpresasService {
  constructor(private readonly supabase: SupabaseService) {}

  async create(userId: string, token: string, dto: CreateEmpresaDto) {
    const client = this.supabase.client(token);
    const { data, error } = await client
      .from('empresas')
      .insert({ ...dto, owner_id: userId })
      .select()
      .single();

    if (error) throw new BadRequestException(error.message);
    return data;
  }

  async list(token: string) {
    const { data, error } = await this.supabase.client(token)
      .from('empresas')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw new BadRequestException(error.message);
    return data;
  }
}
