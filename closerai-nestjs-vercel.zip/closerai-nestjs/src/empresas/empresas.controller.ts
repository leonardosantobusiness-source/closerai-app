import { Body, Controller, Get, Post, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { EmpresasService } from './empresas.service';
import { CreateEmpresaDto } from './empresas.dto';

@Controller('empresas')
@UseGuards(AuthGuard)
export class EmpresasController {
  constructor(private readonly service: EmpresasService) {}

  @Post()
  create(@Req() req: any, @Body() dto: CreateEmpresaDto) {
    return this.service.create(req.user.id, req.accessToken, dto);
  }

  @Get()
  list(@Req() req: any) {
    return this.service.list(req.accessToken);
  }
}
