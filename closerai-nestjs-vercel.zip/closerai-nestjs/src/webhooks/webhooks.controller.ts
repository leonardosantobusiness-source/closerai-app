import { Body, Controller, Get, Headers, Post } from '@nestjs/common';

@Controller('webhooks')
export class WebhooksController {
  @Get('whatsapp')
  verifyWhatsApp(
    @Headers('x-webhook-verify-token') token?: string,
  ) {
    return {
      ok: true,
      message: 'Endpoint de verificação preparado. Configure o provedor de WhatsApp para o formato exigido por ele.',
      receivedToken: Boolean(token),
    };
  }

  @Post('whatsapp')
  receiveWhatsApp(@Body() body: unknown) {
    // Ponto de entrada para mensagens do provedor oficial de WhatsApp.
    // A validação de assinatura e o processamento da mensagem devem ser
    // implementados quando as credenciais e o provedor forem configurados.
    return { received: true, body };
  }
}
