import { Body, Controller, Get, Post, Query, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { ConversasService } from './conversas.service';
import { CreateConversaDto } from './conversas.dto';

@Controller('conversas')
@UseGuards(AuthGuard)
export class ConversasController {
  constructor(private readonly service: ConversasService) {}

  @Post()
  create(@Req() req: any, @Body() dto: CreateConversaDto) {
    return this.service.create(req.accessToken, dto);
  }

  @Get()
  list(@Req() req: any, @Query('empresa_id') empresaId: string) {
    return this.service.list(req.accessToken, empresaId);
  }
}
