import { IsOptional, IsString, IsUUID } from 'class-validator';

export class CreateConversaDto {
  @IsUUID()
  empresa_id!: string;

  @IsOptional()
  @IsUUID()
  cliente_id?: string;

  @IsString()
  canal!: string;

  @IsOptional()
  @IsString()
  status?: string;

  @IsOptional()
  @IsString()
  ultima_mensagem?: string;
}
