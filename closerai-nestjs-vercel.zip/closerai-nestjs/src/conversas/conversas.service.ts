import { BadRequestException, Injectable } from '@nestjs/common';
import { SupabaseService } from '../common/supabase.service';
import { CreateConversaDto } from './conversas.dto';

@Injectable()
export class ConversasService {
  constructor(private readonly supabase: SupabaseService) {}

  async create(token: string, dto: CreateConversaDto) {
    const { data, error } = await this.supabase.client(token)
      .from('conversas')
      .insert(dto)
      .select()
      .single();

    if (error) throw new BadRequestException(error.message);
    return data;
  }

  async list(token: string, empresaId: string) {
    const { data, error } = await this.supabase.client(token)
      .from('conversas')
      .select('*, clientes(*)')
      .eq('empresa_id', empresaId)
      .order('updated_at', { ascending: false });

    if (error) throw new BadRequestException(error.message);
    return data;
  }
}
