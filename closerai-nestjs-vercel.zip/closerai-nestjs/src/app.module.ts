import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AuthModule } from './auth/auth.module';
import { EmpresasModule } from './empresas/empresas.module';
import { ClientesModule } from './clientes/clientes.module';
import { ConversasModule } from './conversas/conversas.module';
import { VendasModule } from './vendas/vendas.module';
import { AgentesModule } from './agentes/agentes.module';
import { ConhecimentoModule } from './conhecimento/conhecimento.module';
import { WebhooksModule } from './webhooks/webhooks.module';
import { SupabaseModule } from './common/supabase.module';
import { HealthController } from './health.controller';

@Module({
  controllers: [HealthController],
  imports: [SupabaseModule,
    ConfigModule.forRoot({ isGlobal: true }),
    AuthModule,
    EmpresasModule,
    ClientesModule,
    ConversasModule,
    VendasModule,
    AgentesModule,
    ConhecimentoModule,
    WebhooksModule,
  ],
})
export class AppModule {}
