import { IsBoolean, IsOptional, IsString, IsUUID } from 'class-validator';

export class UpsertAgenteDto {
  @IsUUID()
  empresa_id!: string;

  @IsString()
  nome!: string;

  @IsOptional()
  @IsString()
  personalidade?: string;

  @IsOptional()
  @IsString()
  objetivo?: string;

  @IsOptional()
  @IsString()
  instrucoes?: string;

  @IsOptional()
  @IsString()
  tom?: string;

  @IsOptional()
  @IsBoolean()
  ativo?: boolean;
}
