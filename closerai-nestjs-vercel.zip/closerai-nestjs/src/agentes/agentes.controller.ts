import { Body, Controller, Get, Post, Query, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { AgentesService } from './agentes.service';
import { UpsertAgenteDto } from './agentes.dto';

@Controller('agentes')
@UseGuards(AuthGuard)
export class AgentesController {
  constructor(private readonly service: AgentesService) {}

  @Post()
  upsert(@Req() req: any, @Body() dto: UpsertAgenteDto) {
    return this.service.upsert(req.accessToken, dto);
  }

  @Get()
  get(@Req() req: any, @Query('empresa_id') empresaId: string) {
    return this.service.get(req.accessToken, empresaId);
  }
}
