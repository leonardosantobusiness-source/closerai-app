import { BadRequestException, Injectable } from '@nestjs/common';
import { SupabaseService } from '../common/supabase.service';
import { UpsertAgenteDto } from './agentes.dto';

@Injectable()
export class AgentesService {
  constructor(private readonly supabase: SupabaseService) {}

  async upsert(token: string, dto: UpsertAgenteDto) {
    const { data, error } = await this.supabase.client(token)
      .from('agentes_ia')
      .upsert(dto, { onConflict: 'empresa_id' })
      .select()
      .single();

    if (error) throw new BadRequestException(error.message);
    return data;
  }

  async get(token: string, empresaId: string) {
    const { data, error } = await this.supabase.client(token)
      .from('agentes_ia')
      .select('*')
      .eq('empresa_id', empresaId)
      .maybeSingle();

    if (error) throw new BadRequestException(error.message);
    return data;
  }
}
