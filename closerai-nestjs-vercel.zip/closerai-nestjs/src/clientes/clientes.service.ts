import { BadRequestException, Injectable } from '@nestjs/common';
import { SupabaseService } from '../common/supabase.service';
import { CreateClienteDto } from './clientes.dto';

@Injectable()
export class ClientesService {
  constructor(private readonly supabase: SupabaseService) {}

  async create(token: string, dto: CreateClienteDto) {
    const { data, error } = await this.supabase.client(token)
      .from('clientes')
      .insert(dto)
      .select()
      .single();

    if (error) throw new BadRequestException(error.message);
    return data;
  }

  async list(token: string, empresaId: string) {
    const { data, error } = await this.supabase.client(token)
      .from('clientes')
      .select('*')
      .eq('empresa_id', empresaId)
      .order('created_at', { ascending: false });

    if (error) throw new BadRequestException(error.message);
    return data;
  }
}
