import { Body, Controller, Get, Post, Query, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { ClientesService } from './clientes.service';
import { CreateClienteDto } from './clientes.dto';

@Controller('clientes')
@UseGuards(AuthGuard)
export class ClientesController {
  constructor(private readonly service: ClientesService) {}

  @Post()
  create(@Req() req: any, @Body() dto: CreateClienteDto) {
    return this.service.create(req.accessToken, dto);
  }

  @Get()
  list(@Req() req: any, @Query('empresa_id') empresaId: string) {
    return this.service.list(req.accessToken, empresaId);
  }
}
