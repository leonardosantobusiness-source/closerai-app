import { Body, Controller, Get, Post, Query, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { ConhecimentoService } from './conhecimento.service';
import { CreateConhecimentoDto } from './conhecimento.dto';

@Controller('conhecimento')
@UseGuards(AuthGuard)
export class ConhecimentoController {
  constructor(private readonly service: ConhecimentoService) {}

  @Post()
  create(@Req() req: any, @Body() dto: CreateConhecimentoDto) {
    return this.service.create(req.accessToken, dto);
  }

  @Get()
  list(@Req() req: any, @Query('empresa_id') empresaId: string) {
    return this.service.list(req.accessToken, empresaId);
  }
}
