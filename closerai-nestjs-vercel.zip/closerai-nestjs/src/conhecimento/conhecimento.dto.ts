import { IsOptional, IsString, IsUUID } from 'class-validator';

export class CreateConhecimentoDto {
  @IsUUID()
  empresa_id!: string;

  @IsString()
  titulo!: string;

  @IsString()
  conteudo!: string;

  @IsOptional()
  @IsString()
  tipo?: string;
}
