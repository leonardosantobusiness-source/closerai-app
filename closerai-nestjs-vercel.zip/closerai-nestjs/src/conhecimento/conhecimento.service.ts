import { BadRequestException, Injectable } from '@nestjs/common';
import { SupabaseService } from '../common/supabase.service';
import { CreateConhecimentoDto } from './conhecimento.dto';

@Injectable()
export class ConhecimentoService {
  constructor(private readonly supabase: SupabaseService) {}

  async create(token: string, dto: CreateConhecimentoDto) {
    const { data, error } = await this.supabase.client(token)
      .from('conhecimento')
      .insert(dto)
      .select()
      .single();

    if (error) throw new BadRequestException(error.message);
    return data;
  }

  async list(token: string, empresaId: string) {
    const { data, error } = await this.supabase.client(token)
      .from('conhecimento')
      .select('*')
      .eq('empresa_id', empresaId)
      .order('created_at', { ascending: false });

    if (error) throw new BadRequestException(error.message);
    return data;
  }
}
