import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { SupabaseService } from '../common/supabase.service';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private readonly supabase: SupabaseService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const req = context.switchToHttp().getRequest();
    const header = req.headers.authorization as string | undefined;

    if (!header?.startsWith('Bearer ')) {
      throw new UnauthorizedException('Use Authorization: Bearer <token>.');
    }

    const token = header.slice(7).trim();
    const user = await this.supabase.requireUser(token);

    req.user = user;
    req.accessToken = token;
    req.supabase = this.supabase.client(token);
    return true;
  }
}
